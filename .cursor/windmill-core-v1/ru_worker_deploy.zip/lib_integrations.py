#!/usr/bin/env python3
"""
Library для интеграций (T-Bank, CDEK)
Общие функции для использования в worker_dispatch и других скриптах.
"""

import os
import json
import time
import requests
from typing import Dict, Any, Optional, Tuple

# T-Bank конфигурация
TBANK_API_URL = os.getenv("TBANK_API_URL", "https://api.tbank.ru/v1/payments")
TBANK_API_BASE = os.getenv("TBANK_API_BASE", "")
TBANK_INVOICE_STATUS_PATH = os.getenv("TBANK_INVOICE_STATUS_PATH", "")
TBANK_INVOICES_LIST_PATH = os.getenv("TBANK_INVOICES_LIST_PATH", "")

# CDEK конфигурация
CDEK_API_BASE = os.getenv("CDEK_API_BASE", "")
CDEK_CLIENT_ID = os.getenv("CDEK_CLIENT_ID", "")
CDEK_CLIENT_SECRET = os.getenv("CDEK_CLIENT_SECRET", "")
CDEK_FROM_LOCATION_CODE = int(os.getenv("CDEK_FROM_LOCATION_CODE", "270"))
CDEK_SENDER_COMPANY = os.getenv("CDEK_SENDER_COMPANY", "")
CDEK_SENDER_PHONE = os.getenv("CDEK_SENDER_PHONE", "")
CDEK_SENDER_ADDRESS = os.getenv("CDEK_SENDER_ADDRESS", "")
CDEK_OAUTH_PATH = os.getenv("CDEK_OAUTH_PATH", "")
CDEK_ORDERS_PATH = os.getenv("CDEK_ORDERS_PATH", "")


def log_event(event: str, data: Dict[str, Any]) -> None:
    """Structured logging в stdout."""
    log_entry = {
        "event": event,
        "timestamp": time.time(),
        **data
    }
    print(json.dumps(log_entry), flush=True)


def execute_tbank_payment(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Выполняет реальный платеж через T-Bank API.
    
    Args:
        payload: dict с amount, currency
    
    Returns:
        dict: Результат выполнения
    """
    try:
        response = requests.post(
            TBANK_API_URL,
            json=payload,
            timeout=10
        )
        response.raise_for_status()
        result = response.json()
        
        return {
            "status": "success",
            "response": result
        }
    except requests.Timeout:
        return {
            "status": "error",
            "error": "Request timeout"
        }
    except requests.HTTPError as e:
        return {
            "status": "error",
            "error": f"HTTP {e.response.status_code}: {e.response.text[:200]}"
        }
    except requests.RequestException as e:
        return {
            "status": "error",
            "error": str(e)
        }
    except Exception as e:
        return {
            "status": "error",
            "error": f"Unexpected error: {str(e)}"
        }


def execute_tbank_invoice_status(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Выполняет реальный запрос статуса счёта через T-Bank API.
    
    Args:
        payload: dict с invoice_id
    
    Returns:
        dict: Результат выполнения с полем "result_status": "paid" | "unpaid" | "not_found" | "unknown" | "error"
    """
    # Проверка конфигурации
    if not TBANK_API_BASE or not TBANK_INVOICE_STATUS_PATH:
        return {
            "status": "error",
            "error": "TBANK NOT CONFIGURED: TBANK_API_BASE, TBANK_INVOICE_STATUS_PATH required",
            "result_status": "error"
        }
    
    invoice_id = payload.get("invoice_id")
    if not invoice_id:
        return {
            "status": "error",
            "error": "invoice_id is required",
            "result_status": "error"
        }
    
    try:
        # Формирование URL с подстановкой invoice_id
        url_template = f"{TBANK_API_BASE.rstrip('/')}/{TBANK_INVOICE_STATUS_PATH.lstrip('/')}"
        url = url_template.replace("{invoice_id}", invoice_id)
        
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        result = response.json()
        
        # Определение статуса из ответа
        result_status = "unknown"
        if isinstance(result, dict):
            status = result.get("status") or result.get("invoice_status") or result.get("state")
            if status:
                status_lower = str(status).lower()
                if "paid" in status_lower or status_lower == "оплачен":
                    result_status = "paid"
                elif "unpaid" in status_lower or status_lower == "не оплачен":
                    result_status = "unpaid"
                elif "not_found" in status_lower or status_lower == "не найден":
                    result_status = "not_found"
                else:
                    result_status = status_lower
        
        return {
            "status": "success",
            "result_status": result_status,
            "response": result
        }
    except requests.Timeout:
        return {
            "status": "error",
            "error": "Request timeout",
            "result_status": "error"
        }
    except requests.HTTPError as e:
        error_text = e.response.text[:200] if e.response else str(e)
        return {
            "status": "error",
            "error": f"TBank HTTP {e.response.status_code}: {error_text}",
            "result_status": "error"
        }
    except requests.RequestException as e:
        return {
            "status": "error",
            "error": f"TBank Request error: {str(e)}",
            "result_status": "error"
        }
    except Exception as e:
        return {
            "status": "error",
            "error": f"TBank Unexpected error: {str(e)}",
            "result_status": "error"
        }


def execute_tbank_invoices_list(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Выполняет реальный запрос списка счетов через T-Bank API.
    
    Args:
        payload: dict с limit (опционально)
    
    Returns:
        dict: Результат выполнения с полем "invoices": список счетов
    """
    # Проверка конфигурации
    if not TBANK_API_BASE or not TBANK_INVOICES_LIST_PATH:
        return {
            "status": "error",
            "error": "TBANK NOT CONFIGURED: TBANK_API_BASE, TBANK_INVOICES_LIST_PATH required",
            "invoices": []
        }
    
    limit = payload.get("limit", 20)
    
    try:
        url = f"{TBANK_API_BASE.rstrip('/')}/{TBANK_INVOICES_LIST_PATH.lstrip('/')}"
        params = {"limit": limit} if limit else {}
        
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        result = response.json()
        
        invoices = []
        if isinstance(result, list):
            for item in result[:limit]:
                invoices.append({
                    "invoice_id": item.get("invoice_id") or item.get("id") or "",
                    "status": item.get("status", "unknown")
                })
        elif isinstance(result, dict) and "invoices" in result:
            for item in result.get("invoices", [])[:limit]:
                invoices.append({
                    "invoice_id": item.get("invoice_id") or item.get("id") or "",
                    "status": item.get("status", "unknown")
                })
        elif isinstance(result, dict) and "data" in result:
            for item in result.get("data", [])[:limit]:
                invoices.append({
                    "invoice_id": item.get("invoice_id") or item.get("id") or "",
                    "status": item.get("status", "unknown")
                })
        
        return {
            "status": "success",
            "invoices": invoices,
            "count": len(invoices)
        }
    except requests.Timeout:
        return {
            "status": "error",
            "error": "Request timeout",
            "invoices": []
        }
    except requests.HTTPError as e:
        error_text = e.response.text[:200] if e.response else str(e)
        return {
            "status": "error",
            "error": f"TBank HTTP {e.response.status_code}: {error_text}",
            "invoices": []
        }
    except requests.RequestException as e:
        return {
            "status": "error",
            "error": f"TBank Request error: {str(e)}",
            "invoices": []
        }
    except Exception as e:
        return {
            "status": "error",
            "error": f"TBank Unexpected error: {str(e)}",
            "invoices": []
        }


def map_tbank_invoice_to_cdek_payload(invoice_id: str, invoice_data: Dict[str, Any]) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Маппинг данных T-Bank invoice в формат CDEK payload с валидацией.
    
    Args:
        invoice_id: str - ID счета
        invoice_data: dict - Данные из T-Bank API response
    
    Returns:
        tuple: (payload_dict, error_str)
        - Если успех: (payload, None)
        - Если ошибка: (None, "error message")
    """
    # Извлечение данных с приоритетом полей
    city = invoice_data.get("city") or invoice_data.get("delivery_city") or invoice_data.get("delivery", {}).get("city")
    address = invoice_data.get("address") or invoice_data.get("delivery_address") or invoice_data.get("delivery", {}).get("address")
    recipient_name = invoice_data.get("recipient_name") or invoice_data.get("name") or invoice_data.get("customer_name")
    phone = invoice_data.get("phone") or invoice_data.get("recipient_phone") or invoice_data.get("customer_phone") or invoice_data.get("contact_phone")
    
    # Валидация обязательных полей
    validation_errors = []
    if not city:
        validation_errors.append("city")
    if not address:
        validation_errors.append("address")
    if not recipient_name:
        validation_errors.append("recipient_name")
    if not phone:
        validation_errors.append("phone")
    
    if validation_errors:
        return (None, f"Missing required fields in invoice data: {', '.join(validation_errors)}")
    
    # Габариты и вес - используем дефолты если нет данных
    weight = int(invoice_data.get("weight", 1000))
    length = int(invoice_data.get("length", 10))
    width = int(invoice_data.get("width", 10))
    height = int(invoice_data.get("height", 10))
    
    # Формирование payload
    payload = {
        "order_id": invoice_id,
        "type": 1,
        "tariff_code": 136,
        "from_location": {
            "code": CDEK_FROM_LOCATION_CODE
        },
        "to_location": {
            "city": city,
            "address": address
        },
        "recipient": {
            "name": recipient_name,
            "phones": [{"number": phone}]
        },
        "sender": {
            "company": CDEK_SENDER_COMPANY,
            "phones": [{"number": CDEK_SENDER_PHONE}],
            "address": CDEK_SENDER_ADDRESS
        },
        "packages": [{
            "weight": weight,
            "length": length,
            "width": width,
            "height": height
        }]
    }
    
    return (payload, None)


def execute_cdek_shipment(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Выполняет реальное создание накладной через CDEK API v2.
    
    Args:
        payload: dict с order_id, type, tariff_code, from_location, to_location, recipient, sender, packages
    
    Returns:
        dict: Результат выполнения
    """
    # Проверка конфигурации
    if not CDEK_API_BASE or not CDEK_CLIENT_ID or not CDEK_CLIENT_SECRET:
        return {
            "status": "error",
            "error": "CDEK NOT CONFIGURED: CDEK_API_BASE, CDEK_CLIENT_ID, CDEK_CLIENT_SECRET required"
        }
    
    if not CDEK_SENDER_COMPANY or not CDEK_SENDER_PHONE or not CDEK_SENDER_ADDRESS:
        return {
            "status": "error",
            "error": "CDEK NOT CONFIGURED: CDEK_SENDER_COMPANY, CDEK_SENDER_PHONE, CDEK_SENDER_ADDRESS required"
        }
    
    if not CDEK_OAUTH_PATH or not CDEK_ORDERS_PATH:
        return {
            "status": "error",
            "error": "CDEK NOT CONFIGURED: CDEK_OAUTH_PATH, CDEK_ORDERS_PATH required"
        }
    
    try:
        # Шаг 1: Получение access token (OAuth client_credentials)
        oauth_url = f"{CDEK_API_BASE.rstrip('/')}/{CDEK_OAUTH_PATH.lstrip('/')}"
        oauth_payload = {
            "grant_type": "client_credentials",
            "client_id": CDEK_CLIENT_ID,
            "client_secret": CDEK_CLIENT_SECRET
        }
        
        oauth_response = requests.post(
            oauth_url,
            json=oauth_payload,
            timeout=10
        )
        oauth_response.raise_for_status()
        oauth_data = oauth_response.json()
        access_token = oauth_data.get("access_token")
        
        if not access_token:
            return {
                "status": "error",
                "error": "CDEK OAuth failed: no access_token"
            }
        
        # Шаг 2: Создание накладной
        orders_url = f"{CDEK_API_BASE.rstrip('/')}/{CDEK_ORDERS_PATH.lstrip('/')}"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        
        cdek_body = payload
        
        response = requests.post(
            orders_url,
            json=cdek_body,
            headers=headers,
            timeout=30
        )
        response.raise_for_status()
        result = response.json()
        
        return {
            "status": "success",
            "response": result
        }
    except requests.Timeout:
        return {
            "status": "error",
            "error": "CDEK Request timeout"
        }
    except requests.HTTPError as e:
        error_text = e.response.text[:500] if e.response else str(e)
        return {
            "status": "error",
            "error": f"CDEK HTTP {e.response.status_code}: {error_text}"
        }
    except requests.RequestException as e:
        return {
            "status": "error",
            "error": f"CDEK Request error: {str(e)}"
        }
    except Exception as e:
        return {
            "status": "error",
            "error": f"CDEK Unexpected error: {str(e)}"
        }

