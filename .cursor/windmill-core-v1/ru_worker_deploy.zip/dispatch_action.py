#!/usr/bin/env python3
"""
Dispatch Action для Windmill
Единая точка для всех side-effects (полная версия без зависимостей от telegram_bot_mvp0.py).
"""

import os
import json
import time
import hashlib
from typing import Dict, Any, Optional

# Импорт интеграций
from lib_integrations import (
    execute_tbank_payment,
    execute_tbank_invoice_status,
    execute_tbank_invoices_list,
    execute_cdek_shipment,
    map_tbank_invoice_to_cdek_payload
)

# Конфигурация
ACTION_MODE = os.getenv("ACTION_MODE", "REAL")

# Idempotency cache (in-memory, для одного запуска)
action_cache = {}
CACHE_TTL = 60  # секунд


def log_event(event: str, data: Dict[str, Any]) -> None:
    """Structured logging в stdout."""
    log_entry = {
        "event": event,
        "timestamp": time.time(),
        **data
    }
    print(json.dumps(log_entry), flush=True)


def generate_action_key(action_type: str, payload: Dict[str, Any], user_id: Optional[int]) -> str:
    """
    Генерирует ключ для idempotency cache.
    """
    key_data = {
        "action_type": action_type,
        "payload": payload,
        "user_id": user_id
    }
    key_str = json.dumps(key_data, sort_keys=True)
    return str(hash(key_str))


def cleanup_action_cache(ttl: int = CACHE_TTL) -> None:
    """
    Очищает устаревшие записи из кэша.
    """
    current_time = time.time()
    expired_keys = [
        key for key, timestamp in action_cache.items()
        if current_time - timestamp > ttl
    ]
    for key in expired_keys:
        del action_cache[key]


def dispatch_action(action: Dict[str, Any], mode: Optional[str] = None) -> Dict[str, Any]:
    """
    Единая точка для всех side-effects.
    
    Args:
        action: Action dict с action_type, payload, source, metadata
        mode: "DRY_RUN" (по умолчанию) или "REAL"
    
    Returns:
        dict: Результат выполнения (в DRY_RUN - только логирование)
    """
    if mode is None:
        mode = ACTION_MODE
    
    action_type = action.get("action_type")
    payload = action.get("payload", {})
    source = action.get("source", "unknown")
    metadata = action.get("metadata", {})
    user_id = metadata.get("user_id")
    
    # Очистка устаревших записей
    cleanup_action_cache()
    
    # Проверка дубликатов
    cache_key = generate_action_key(action_type, payload, user_id)
    current_time = time.time()
    
    if cache_key in action_cache:
        # Дубликат найден в TTL
        # Исключение: для tbank_invoices_list в DRY_RUN всегда возвращаем список счетов
        if action_type == "tbank_invoices_list" and mode == "DRY_RUN":
            fake_invoices = [
                {"invoice_id": "INV-001", "status": "paid"},
                {"invoice_id": "INV-002", "status": "unpaid"},
                {"invoice_id": "INV-003", "status": "paid"},
                {"invoice_id": "INV-004", "status": "unpaid"},
                {"invoice_id": "INV-005", "status": "paid"}
            ]
            log_event("action_duplicate_but_returned_invoices", {
                "action_type": action_type,
                "mode": mode,
                "source": source,
                "cache_key": cache_key
            })
            return {
                "status": "success",
                "action_type": action_type,
                "invoices": fake_invoices
            }
        
        # Для остальных действий - стандартная обработка дубликатов
        log_event("action_duplicate_skipped", {
            "action_type": action_type,
            "mode": mode,
            "source": source,
            "cache_key": cache_key
        })
        return {
            "status": "duplicate",
            "action_type": action_type,
            "message": "Duplicate action skipped (within TTL)"
        }
    
    # Сохранение в кэш
    action_cache[cache_key] = current_time
    
    if mode == "DRY_RUN":
        # Логирование намерения
        log_event("action_dispatched", {
            "action_type": action_type,
            "mode": mode,
            "source": source,
            "payload": payload,
            "metadata": metadata
        })
        
        # Только логирование, никаких реальных вызовов
        if action_type == "tbank_invoices_list":
            fake_invoices = [
                {"invoice_id": "INV-001", "status": "paid"},
                {"invoice_id": "INV-002", "status": "unpaid"},
                {"invoice_id": "INV-003", "status": "paid"},
                {"invoice_id": "INV-004", "status": "unpaid"},
                {"invoice_id": "INV-005", "status": "paid"}
            ]
            return {
                "status": "success",
                "action_type": action_type,
                "invoices": fake_invoices
            }
        elif action_type == "ship_paid":
            invoice_id = payload.get("invoice_id", "")
            fake_tracking_number = f"TEST-{int(time.time()) % 100000}"
            
            log_event("ship_paid_requested", {
                "action_type": action_type,
                "mode": mode,
                "source": source,
                "invoice_id": invoice_id
            })
            
            return {
                "status": "success",
                "action_type": action_type,
                "tracking_number": fake_tracking_number,
                "dry_run": True
            }
        elif action_type == "cdek_shipment":
            invoice_id = payload.get("invoice_id")
            if invoice_id:
                import uuid
                fake_tracking_number = f"TEST-{uuid.uuid4().hex[:5].upper()}"
                
                log_event("cdek_shipment_requested", {
                    "action_type": action_type,
                    "mode": mode,
                    "source": source,
                    "invoice_id": invoice_id
                })
                
                return {
                    "status": "success",
                    "action_type": action_type,
                    "tracking_number": fake_tracking_number,
                    "dry_run": True
                }
            else:
                return {
                    "status": "dry_run",
                    "action_type": action_type,
                    "message": "Action logged, not executed"
                }
        elif action_type == "auto_ship_all_paid":
            fake_results = [
                {"invoice_id": "INV-001", "status": "success", "tracking": "TEST-001"},
                {"invoice_id": "INV-003", "status": "success", "tracking": "TEST-003"},
                {"invoice_id": "INV-005", "status": "success", "tracking": "TEST-005"}
            ]
            
            log_event("auto_ship_all_paid_requested", {
                "action_type": action_type,
                "mode": mode,
                "source": source
            })
            
            return {
                "status": "success",
                "action_type": action_type,
                "dry_run": True,
                "processed_count": len(fake_results),
                "success_count": len(fake_results),
                "results": fake_results
            }
        
        return {
            "status": "dry_run",
            "action_type": action_type,
            "message": "Action logged, not executed"
        }
    
    elif mode == "REAL":
        # Реальное выполнение для tbank_payment
        if action_type == "tbank_payment":
            try:
                result = execute_tbank_payment(payload)
                
                if result.get("status") == "success":
                    log_event("action_real_executed", {
                        "action_type": action_type,
                        "mode": mode,
                        "source": source,
                        "result": result
                    })
                    return {
                        "status": "success",
                        "action_type": action_type,
                        "result": result
                    }
                else:
                    log_event("action_real_failed", {
                        "action_type": action_type,
                        "mode": mode,
                        "source": source,
                        "error": result.get("error", "Unknown error")
                    })
                    return {
                        "status": "error",
                        "action_type": action_type,
                        "error": result.get("error", "Unknown error")
                    }
            except Exception as e:
                log_event("action_real_failed", {
                    "action_type": action_type,
                    "mode": mode,
                    "source": source,
                    "error": str(e)
                })
                return {
                    "status": "error",
                    "action_type": action_type,
                    "error": str(e)
                }
        
        # Реальное выполнение для cdek_shipment
        elif action_type == "cdek_shipment":
            try:
                invoice_id = payload.get("invoice_id")
                
                # Если есть invoice_id, используем логику из ship_paid
                if invoice_id:
                    # Шаг 1: Проверка статуса счёта в T-Bank
                    invoice_status_result = execute_tbank_invoice_status({"invoice_id": invoice_id})
                    
                    if invoice_status_result.get("status") != "success":
                        log_event("action_real_failed", {
                            "action_type": action_type,
                            "mode": mode,
                            "source": source,
                            "invoice_id": invoice_id,
                            "error": invoice_status_result.get("error", "Failed to check invoice status")
                        })
                        return {
                            "status": "error",
                            "action_type": action_type,
                            "error": invoice_status_result.get("error", "Failed to check invoice status")
                        }
                    
                    result_status = invoice_status_result.get("result_status", "unknown")
                    
                    # Шаг 2: Проверка, что счёт оплачен
                    if result_status != "paid":
                        log_event("action_real_blocked_not_paid", {
                            "action_type": action_type,
                            "mode": mode,
                            "source": source,
                            "invoice_id": invoice_id,
                            "invoice_status": result_status
                        })
                        return {
                            "status": "not_paid",
                            "action_type": action_type,
                            "invoice_status": result_status
                        }
                    
                    # Шаг 3: Счёт оплачен - создаём CDEK shipment
                    invoice_response = invoice_status_result.get("response", {})
                    
                    # Маппинг данных T-Bank → CDEK с валидацией
                    cdek_payload, mapping_error = map_tbank_invoice_to_cdek_payload(invoice_id, invoice_response)
                    
                    if mapping_error:
                        log_event("action_real_failed", {
                            "action_type": action_type,
                            "mode": mode,
                            "source": source,
                            "invoice_id": invoice_id,
                            "error": f"Data mapping failed: {mapping_error}"
                        })
                        return {
                            "status": "error",
                            "action_type": action_type,
                            "error": f"Data mapping failed: {mapping_error}"
                        }
                    
                    # Вызов CDEK shipment
                    result = execute_cdek_shipment(cdek_payload)
                else:
                    # Обычный cdek_shipment с полным payload
                    result = execute_cdek_shipment(payload)
                
                if result.get("status") == "success":
                    log_event("action_real_executed", {
                        "action_type": action_type,
                        "mode": mode,
                        "source": source,
                        "result": result
                    })
                    return {
                        "status": "success",
                        "action_type": action_type,
                        "result": result
                    }
                else:
                    log_event("action_real_failed", {
                        "action_type": action_type,
                        "mode": mode,
                        "source": source,
                        "error": result.get("error", "Unknown error")
                    })
                    return {
                        "status": "error",
                        "action_type": action_type,
                        "error": result.get("error", "Unknown error")
                    }
            except Exception as e:
                log_event("action_real_failed", {
                    "action_type": action_type,
                    "mode": mode,
                    "source": source,
                    "error": str(e)
                })
                return {
                    "status": "error",
                    "action_type": action_type,
                    "error": str(e)
                }
        
        # Реальное выполнение для tbank_invoice_status
        elif action_type == "tbank_invoice_status":
            try:
                result = execute_tbank_invoice_status(payload)
                invoice_id = payload.get("invoice_id", "")
                
                if result.get("status") == "success":
                    log_event("action_real_executed", {
                        "action_type": action_type,
                        "mode": mode,
                        "source": source,
                        "invoice_id": invoice_id,
                        "result_status": result.get("result_status", "unknown")
                    })
                    return {
                        "status": "success",
                        "action_type": action_type,
                        "result": result
                    }
                else:
                    log_event("action_real_failed", {
                        "action_type": action_type,
                        "mode": mode,
                        "source": source,
                        "invoice_id": invoice_id,
                        "error": result.get("error", "Unknown error")
                    })
                    return {
                        "status": "error",
                        "action_type": action_type,
                        "error": result.get("error", "Unknown error")
                    }
            except Exception as e:
                invoice_id = payload.get("invoice_id", "")
                log_event("action_real_failed", {
                    "action_type": action_type,
                    "mode": mode,
                    "source": source,
                    "invoice_id": invoice_id,
                    "error": str(e)
                })
                return {
                    "status": "error",
                    "action_type": action_type,
                    "error": str(e)
                }
        
        # Реальное выполнение для tbank_invoices_list
        elif action_type == "tbank_invoices_list":
            try:
                # Если есть invoice_ids, проверяем каждый
                invoice_ids = payload.get("invoice_ids", [])
                if invoice_ids:
                    invoices = []
                    for invoice_id in invoice_ids:
                        status_result = execute_tbank_invoice_status({"invoice_id": invoice_id})
                        result_status = status_result.get("result_status", "error")
                        invoices.append({
                            "invoice_id": invoice_id,
                            "status": result_status
                        })
                    
                    log_event("action_real_executed", {
                        "action_type": action_type,
                        "mode": mode,
                        "source": source,
                        "invoices_count": len(invoices)
                    })
                    return {
                        "status": "success",
                        "action_type": action_type,
                        "invoices": invoices
                    }
                else:
                    # Получаем список всех счетов
                    invoices_result = execute_tbank_invoices_list(payload)
                    
                    if invoices_result.get("status") == "success":
                        log_event("action_real_executed", {
                            "action_type": action_type,
                            "mode": mode,
                            "source": source,
                            "invoices_count": len(invoices_result.get("invoices", []))
                        })
                        return {
                            "status": "success",
                            "action_type": action_type,
                            "invoices": invoices_result.get("invoices", [])
                        }
                    else:
                        log_event("action_real_failed", {
                            "action_type": action_type,
                            "mode": mode,
                            "source": source,
                            "error": invoices_result.get("error", "Unknown error")
                        })
                        return {
                            "status": "error",
                            "action_type": action_type,
                            "error": invoices_result.get("error", "Unknown error")
                        }
            except Exception as e:
                log_event("action_real_failed", {
                    "action_type": action_type,
                    "mode": mode,
                    "source": source,
                    "error": str(e)
                })
                return {
                    "status": "error",
                    "action_type": action_type,
                    "error": str(e)
                }
        
        # Реальное выполнение для ship_paid
        elif action_type == "ship_paid":
            try:
                invoice_id = payload.get("invoice_id", "")
                
                # Шаг 1: Проверка статуса счёта в T-Bank
                invoice_status_result = execute_tbank_invoice_status({"invoice_id": invoice_id})
                
                if invoice_status_result.get("status") != "success":
                    log_event("action_real_failed", {
                        "action_type": action_type,
                        "mode": mode,
                        "source": source,
                        "invoice_id": invoice_id,
                        "error": invoice_status_result.get("error", "Failed to check invoice status")
                    })
                    return {
                        "status": "error",
                        "action_type": action_type,
                        "error": invoice_status_result.get("error", "Failed to check invoice status")
                    }
                
                result_status = invoice_status_result.get("result_status", "unknown")
                
                # Шаг 2: Проверка, что счёт оплачен
                if result_status != "paid":
                    log_event("action_real_blocked_not_paid", {
                        "action_type": action_type,
                        "mode": mode,
                        "source": source,
                        "invoice_id": invoice_id,
                        "invoice_status": result_status
                    })
                    return {
                        "status": "not_paid",
                        "action_type": action_type,
                        "invoice_status": result_status
                    }
                
                # Шаг 3: Счёт оплачен - создаём CDEK shipment
                invoice_response = invoice_status_result.get("response", {})
                
                # Маппинг данных T-Bank → CDEK с валидацией
                cdek_payload, mapping_error = map_tbank_invoice_to_cdek_payload(invoice_id, invoice_response)
                
                if mapping_error:
                    log_event("action_real_failed", {
                        "action_type": action_type,
                        "mode": mode,
                        "source": source,
                        "invoice_id": invoice_id,
                        "error": f"Data mapping failed: {mapping_error}"
                    })
                    return {
                        "status": "error",
                        "action_type": action_type,
                        "error": f"Data mapping failed: {mapping_error}"
                    }
                
                # Вызов CDEK shipment
                cdek_result = execute_cdek_shipment(cdek_payload)
                
                if cdek_result.get("status") == "success":
                    # Извлечение трек-номера из ответа CDEK
                    cdek_response = cdek_result.get("response", {})
                    tracking_number = (
                        cdek_response.get("entity", {}).get("uuid") or
                        cdek_response.get("requests", [{}])[0].get("request_uuid") if cdek_response.get("requests") else None or
                        cdek_response.get("uuid") or
                        cdek_response.get("tracking_number") or
                        cdek_response.get("number") or
                        "N/A"
                    )
                    
                    log_event("ship_paid_success", {
                        "invoice_id": invoice_id,
                        "user_id": metadata.get("user_id"),
                        "chat_id": metadata.get("chat_id"),
                        "tracking_number": tracking_number,
                        "dry_run": False
                    })
                    
                    return {
                        "status": "success",
                        "action_type": action_type,
                        "result": cdek_result
                    }
                else:
                    error_msg = cdek_result.get("error", "CDEK shipment failed")
                    log_event("ship_paid_failed", {
                        "invoice_id": invoice_id,
                        "user_id": metadata.get("user_id"),
                        "chat_id": metadata.get("chat_id"),
                        "error": error_msg
                    })
                    return {
                        "status": "error",
                        "action_type": action_type,
                        "error": cdek_result.get("error", "CDEK shipment failed")
                    }
            except Exception as e:
                invoice_id = payload.get("invoice_id", "")
                log_event("action_real_failed", {
                    "action_type": action_type,
                    "mode": mode,
                    "source": source,
                    "invoice_id": invoice_id,
                    "error": str(e)
                })
                return {
                    "status": "error",
                    "action_type": action_type,
                    "error": str(e)
                }
        
        elif action_type == "auto_ship_all_paid":
            # Реальное выполнение для auto_ship_all_paid
            try:
                # Шаг 1: Получаем список счетов
                invoices_result = execute_tbank_invoices_list({"limit": 50})
                
                if invoices_result.get("status") != "success":
                    return {
                        "status": "error",
                        "action_type": action_type,
                        "error": f"Failed to get invoices: {invoices_result.get('error')}"
                    }
                
                invoices = invoices_result.get("invoices", [])
                paid_invoices = [inv for inv in invoices if inv.get("status") == "paid"]
                
                if not paid_invoices:
                    return {
                        "status": "success",
                        "action_type": action_type,
                        "processed_count": 0,
                        "success_count": 0,
                        "message": "Нет оплаченных счетов для обработки",
                        "results": []
                    }
                
                # Шаг 2: Создаем накладные для каждого оплаченного счета
                results = []
                for invoice in paid_invoices:
                    invoice_id = invoice.get("invoice_id")
                    if not invoice_id:
                        continue
                    
                    try:
                        # Проверяем статус и создаем накладную
                        invoice_status_result = execute_tbank_invoice_status({"invoice_id": invoice_id})
                        
                        if invoice_status_result.get("status") != "success":
                            results.append({
                                "invoice_id": invoice_id,
                                "status": "error",
                                "error": invoice_status_result.get("error", "Unknown error")
                            })
                            continue
                        
                        if invoice_status_result.get("result_status") != "paid":
                            results.append({
                                "invoice_id": invoice_id,
                                "status": "skipped",
                                "reason": "not_paid"
                            })
                            continue
                        
                        # Маппинг и создание накладной
                        invoice_response = invoice_status_result.get("response", {})
                        cdek_payload, mapping_error = map_tbank_invoice_to_cdek_payload(invoice_id, invoice_response)
                        
                        if mapping_error:
                            results.append({
                                "invoice_id": invoice_id,
                                "status": "error",
                                "error": f"Mapping failed: {mapping_error}"
                            })
                            continue
                        
                        # Создание накладной
                        cdek_result = execute_cdek_shipment(cdek_payload)
                        
                        if cdek_result.get("status") == "success":
                            cdek_response = cdek_result.get("response", {})
                            tracking = (
                                cdek_response.get("entity", {}).get("uuid") or
                                cdek_response.get("requests", [{}])[0].get("request_uuid") if cdek_response.get("requests") else None or
                                cdek_response.get("uuid") or
                                "N/A"
                            )
                            results.append({
                                "invoice_id": invoice_id,
                                "status": "success",
                                "tracking": tracking
                            })
                        else:
                            results.append({
                                "invoice_id": invoice_id,
                                "status": "error",
                                "error": cdek_result.get("error", "Unknown error")
                            })
                    except Exception as e:
                        results.append({
                            "invoice_id": invoice_id,
                            "status": "error",
                            "error": str(e)
                        })
                
                success_count = len([r for r in results if r.get("status") == "success"])
                
                log_event("auto_ship_all_paid_completed", {
                    "action_type": action_type,
                    "mode": mode,
                    "source": source,
                    "processed_count": len(results),
                    "success_count": success_count
                })
                
                return {
                    "status": "success",
                    "action_type": action_type,
                    "processed_count": len(results),
                    "success_count": success_count,
                    "results": results
                }
                
            except Exception as e:
                log_event("action_real_failed", {
                    "action_type": action_type,
                    "mode": mode,
                    "source": source,
                    "error": str(e)
                })
                return {
                    "status": "error",
                    "action_type": action_type,
                    "error": str(e)
                }
        
        else:
            # Блокировка для всех прочих action_type
            log_event("action_real_blocked", {
                "action_type": action_type,
                "mode": mode,
                "source": source
            })
            return {
                "status": "blocked",
                "action_type": action_type,
                "message": "REAL mode not implemented"
            }
    
    else:
        return {
            "status": "error",
            "error": f"Unknown mode: {mode}"
        }

