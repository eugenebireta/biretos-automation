"""
RFQ Execution Core Business v1 - RU Worker
Executor для выполнения RU-side бизнес-логики (test_job, rfq_v1_from_ocr)

ВАЖНО: Это polling executor на RU-VPS, не публичный сервис.

EXECUTION NODE: RU VPS (77.233.222.214) - ЕДИНСТВЕННЫЙ execution node.
Все job_types обрабатываются ТОЛЬКО на RU VPS:
- telegram_update → telegram_command → sendMessage
- tbank_invoice_paid → FSM v2
- cdek_shipment_status → order_event
- order_event → FSM v2
- rfq_v1_from_ocr → RFQ pipeline
- test_job → simple test

USA VPS НЕ используется для execution.
"""

import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
from uuid import uuid4, UUID

import psycopg2
from psycopg2.extras import RealDictCursor
import requests

# Загрузка переменных окружения из .env файла
try:
    from dotenv import load_dotenv
    env_path = Path(__file__).parent.parent / ".env"
    load_dotenv(env_path)
except ImportError:
    pass  # python-dotenv не установлен, используем только системные переменные

# Импорты для RFQ pipeline
from rfq_parser import parse_rfq_deterministic, merge_llm_results
from llm_client import parse_rfq_with_llm

# Импорт FSM v2
from fsm_v2 import Event, LedgerRecord, FSMResult, fsm_v2_process_event

# Импорт CDEK Order Mapper
from cdek_order_mapper import map_cdek_to_order_event, OrderEvent as CDEKOrderEvent

# Импорт Side-Effect Workers
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'side_effects'))
from telegram_command_worker import execute_telegram_command
from cdek_shipment_worker import execute_cdek_shipment
from insales_paid_worker import execute_insales_paid_sync
from invoice_worker import execute_invoice_create

# Новые модульные компоненты
from telegram_router import route_update, extract_chat_id_from_update
from dispatch_action import dispatch_action

# Конфигурация PostgreSQL
POSTGRES_HOST = os.getenv("POSTGRES_HOST", "localhost")
POSTGRES_PORT = int(os.getenv("POSTGRES_PORT", "5432"))
POSTGRES_DB = os.getenv("POSTGRES_DB", "biretos_automation")
POSTGRES_USER = os.getenv("POSTGRES_USER", "biretos_user")
POSTGRES_PASSWORD = os.getenv("POSTGRES_PASSWORD", "")

# Конфигурация worker
POLL_INTERVAL = int(os.getenv("RU_WORKER_POLL_INTERVAL", "5"))  # секунды
LLM_ENABLED_DEFAULT = os.getenv("LLM_ENABLED_DEFAULT", "false").lower() == "true"

# Telegram API
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_API_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}" if TELEGRAM_BOT_TOKEN else ""

# State storage
STATE_TABLE_INITIALIZED = False


def log_event(event: str, data: Dict[str, Any]) -> None:
    """Structured logging helper."""
    log_entry = {
        "event": event,
        "timestamp": time.time(),
        **data
    }
    print(json.dumps(log_entry), flush=True)


def ensure_state_table(conn) -> None:
    """Создаёт таблицу для key-value state, если её ещё нет."""
    global STATE_TABLE_INITIALIZED
    if STATE_TABLE_INITIALIZED:
        return
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wm_state (
            key TEXT PRIMARY KEY,
            value JSONB,
            updated_at TIMESTAMPTZ DEFAULT NOW()
        )
        """
    )
    conn.commit()
    STATE_TABLE_INITIALIZED = True


def get_state(conn, key: str) -> Optional[Dict[str, Any]]:
    """Получает значение state по ключу."""
    ensure_state_table(conn)
    cursor = conn.cursor()
    cursor.execute("SELECT value FROM wm_state WHERE key = %s", (key,))
    row = cursor.fetchone()
    return row[0] if row else None


def set_state(conn, key: str, value: Dict[str, Any]) -> None:
    """Устанавливает значение state (upsert)."""
    ensure_state_table(conn)
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO wm_state (key, value, updated_at)
        VALUES (%s, %s::jsonb, NOW())
        ON CONFLICT (key) DO UPDATE
        SET value = EXCLUDED.value,
            updated_at = NOW()
        """,
        (key, json.dumps(value, ensure_ascii=False))
    )
    conn.commit()


def delete_state(conn, key: str) -> None:
    """Удаляет запись state."""
    ensure_state_table(conn)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM wm_state WHERE key = %s", (key,))
    conn.commit()


def send_telegram_message(chat_id: int, text: str, reply_markup: Optional[Dict[str, Any]] = None) -> bool:
    """Отправляет сообщение в Telegram."""
    if not TELEGRAM_API_URL:
        log_event("telegram_send_error", {
            "error": "TELEGRAM_BOT_TOKEN not configured",
            "chat_id": chat_id
        })
        return False
    payload = {
        "chat_id": chat_id,
        "text": text
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    try:
        response = requests.post(
            f"{TELEGRAM_API_URL}/sendMessage",
            json=payload,
            timeout=10
        )
        response.raise_for_status()
        log_event("telegram_message_sent", {
            "chat_id": chat_id,
            "text_length": len(text),
            "has_reply_markup": bool(reply_markup)
        })
        return True
    except requests.RequestException as e:
        log_event("telegram_send_error", {
            "error": str(e),
            "chat_id": chat_id
        })
        return False


def answer_callback_query(callback_query_id: str, text: str = "", show_alert: bool = False) -> bool:
    """Отвечает на callback_query, чтобы Telegram не показывал спиннер."""
    if not TELEGRAM_API_URL:
        return False
    try:
        response = requests.post(
            f"{TELEGRAM_API_URL}/answerCallbackQuery",
            json={
                "callback_query_id": callback_query_id,
                "text": text,
                "show_alert": show_alert
            },
            timeout=5
        )
        response.raise_for_status()
        log_event("telegram_callback_acked", {
            "callback_query_id": callback_query_id
        })
        return True
    except requests.RequestException as e:
        log_event("telegram_callback_ack_error", {
            "callback_query_id": callback_query_id,
            "error": str(e)
        })
        return False


def extract_tracking_from_result(result: Dict[str, Any]) -> Optional[str]:
    """Извлекает tracking номер из результата dispatch_action."""
    if not result:
        return None
    response = result.get("result") or result.get("response")
    if not response and "result" in result:
        response = result.get("result", {}).get("response")
    if not isinstance(response, dict):
        return None
    entity = response.get("entity", {})
    if isinstance(entity, dict):
        tracking = entity.get("uuid") or entity.get("barcode")
        if tracking:
            return tracking
    requests_list = response.get("requests")
    if isinstance(requests_list, list) and requests_list:
        first = requests_list[0]
        if isinstance(first, dict):
            tracking = first.get("request_uuid") or first.get("uuid")
            if tracking:
                return tracking
    return None


def format_action_result(action: Dict[str, Any], result: Dict[str, Any]) -> Tuple[Optional[str], Optional[Dict[str, Any]]]:
    """Форматирует результат action для отправки пользователю."""
    action_type = action.get("action_type")
    status = result.get("status")

    if action_type == "ship_paid":
        if status == "success":
            tracking = extract_tracking_from_result(result) or result.get("tracking_number") or "N/A"
            return (f"✅ Накладная создана!\nТрек-номер: {tracking}", None)
        elif status == "duplicate":
            tracking = result.get("tracking", "N/A")
            return (f"✅ Накладная уже создана!\nТрек-номер: {tracking}", None)
        elif status == "not_paid":
            return ("❌ Счёт не оплачен", None)
        else:
            error = result.get("error", "Unknown error")
            return (f"❌ Ошибка: {error}", None)

    if action_type == "auto_ship_all_paid":
        if status == "success":
            processed = result.get("processed_count", 0)
            success = result.get("success_count", 0)
            lines = [
                "🚀 Автоматическая обработка завершена",
                "",
                f"📊 Обработано: {processed} счетов",
                f"✅ Успешно: {success}"
            ]
            results = result.get("results", [])
            success_items = [r for r in results if r.get("status") == "success"]
            if success_items:
                lines.append("")
                lines.append("📦 Созданные накладные:")
                for item in success_items[:10]:
                    lines.append(f"  ✓ {item.get('invoice_id')}: {item.get('tracking', 'N/A')}")
            errors = [r for r in results if r.get("status") == "error"]
            if errors:
                lines.append("")
                lines.append(f"❌ Ошибки: {len(errors)}")
                for item in errors[:5]:
                    error_msg = item.get("error", "Unknown error")
                    if len(error_msg) > 50:
                        error_msg = error_msg[:47] + "..."
                    lines.append(f"  ✗ {item.get('invoice_id')}: {error_msg}")
            if len(results) > 10:
                lines.append("")
                lines.append(f"... и еще {len(results) - 10} счетов")
            return ("\n".join(lines), None)
        else:
            error = result.get("error", "Unknown error")
            return (f"❌ Ошибка: {error}", None)

    if action_type == "tbank_invoices_list":
        if status == "success":
            invoices = result.get("invoices", [])
            if not invoices:
                return ("🧾 Последние счета\nСчета не найдены", None)
            lines = ["🧾 Последние счета"]
            inline_keyboard = []
            for inv in invoices:
                invoice_id = inv.get("invoice_id", "N/A")
                inv_status = inv.get("status", "unknown")
                if inv_status == "paid":
                    status_text = "✅ Оплачен"
                    inline_keyboard.append([{
                        "text": "📦 Создать накладную",
                        "callback_data": f"ship_paid:{invoice_id}"
                    }])
                else:
                    status_text = "⏳ Не оплачен"
                lines.append(f"{invoice_id} — {status_text}")
            reply_markup = {"inline_keyboard": inline_keyboard} if inline_keyboard else None
            return ("\n".join(lines), reply_markup)
        else:
            return ("❌ Ошибка получения счетов", None)

    if action_type == "tbank_invoice_status":
        if status == "success":
            invoice_status = result.get("result", {}).get("result_status") or result.get("result_status", "unknown")
            invoice_id = action.get("payload", {}).get("invoice_id", "N/A")
            status_emoji = "✅" if invoice_status == "paid" else "⏳"
            return (f"{status_emoji} Счёт {invoice_id}: {invoice_status}", None)
        else:
            error = result.get("error", "Unknown error")
            return (f"❌ Ошибка: {error}", None)

    if status == "success":
        return ("✅ Выполнено", None)
    elif status == "error":
        error = result.get("error", "Unknown error")
        return (f"❌ Ошибка: {error}", None)
    elif status == "duplicate":
        return ("ℹ️ Действие уже выполняется", None)
    else:
        return (f"ℹ️ Статус: {status}", None)


def handle_router_action(action: Dict[str, Any], db_conn) -> Dict[str, Any]:
    """
    Выполняет action, возвращенный telegram_router.
    Обрабатывает бизнес-идемпотентность и форматирует ответ пользователю.
    """
    action_type = action.get("action_type")
    metadata = action.get("metadata", {})
    chat_id = metadata.get("chat_id")
    user_id = metadata.get("user_id")
    result: Dict[str, Any] = {"status": "noop"}

    if action_type == "ship_paid":
        invoice_id = action.get("payload", {}).get("invoice_id")
        if not invoice_id:
            log_event("router_action_error", {
                "action_type": action_type,
                "error": "invoice_id missing"
            })
            return {
                "status": "error",
                "error": "invoice_id missing"
            }

        state_key = f"business:ship_paid:{invoice_id}"
        state = get_state(db_conn, state_key)
        if state and state.get("status") == "shipped":
            tracking = state.get("tracking", "N/A")
            log_event("ship_paid_idempotent_skip", {
                "invoice_id": invoice_id,
                "tracking": tracking
            })
            if chat_id:
                send_telegram_message(chat_id, f"✅ Накладная уже создана!\nТрек-номер: {tracking}")
            return {
                "status": "duplicate",
                "tracking": tracking
            }
        elif state and state.get("status") == "processing":
            log_event("ship_paid_processing_skip", {
                "invoice_id": invoice_id
            })
            if chat_id:
                send_telegram_message(chat_id, "⏳ Накладная уже создаётся, подождите немного.")
            return {
                "status": "duplicate",
                "message": "processing"
            }

        set_state(db_conn, state_key, {
            "status": "processing",
            "chat_id": chat_id,
            "user_id": user_id,
            "timestamp": time.time()
        })

        result = dispatch_action(action)

        if result.get("status") == "success":
            tracking = extract_tracking_from_result(result) or result.get("tracking_number")
            set_state(db_conn, state_key, {
                "status": "shipped",
                "tracking": tracking,
                "chat_id": chat_id,
                "user_id": user_id,
                "timestamp": time.time()
            })
        elif result.get("status") == "duplicate":
            set_state(db_conn, state_key, {
                "status": "duplicate",
                "timestamp": time.time()
            })
        else:
            set_state(db_conn, state_key, {
                "status": "failed",
                "error": result.get("error"),
                "timestamp": time.time()
            })

    else:
        result = dispatch_action(action)

    message_text, reply_markup = format_action_result(action, result)
    if message_text and chat_id:
        send_telegram_message(chat_id, message_text, reply_markup)

    return result


def get_db_connection():
    """Создает подключение к PostgreSQL"""
    return psycopg2.connect(
        host=POSTGRES_HOST,
        port=POSTGRES_PORT,
        dbname=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD,
    )


def execute_test_job(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Выполняет простую тестовую задачу"""
    time.sleep(1)  # Фиктивное выполнение
    return {
        "job_type": "test_job",
        "message": "Test job completed",
        "payload": payload
    }


def execute_tbank_invoice_paid(payload: Dict[str, Any], db_conn) -> Dict[str, Any]:
    """
    Выполняет обработку T-Bank webhook INVOICE_PAID через FSM v2:
    1. Lookup order_ledger по tbank_invoice_id
    2. Если не найден - логируем ошибку, job completed
    3. Если найден - вызываем FSM v2 для определения изменений
    4. Применяем изменения к Ledger
    """
    invoice_id = payload.get("invoice_id")
    invoice_number = payload.get("invoice_number")
    paid_at = payload.get("paid_at", datetime.utcnow().isoformat() + "Z")
    
    if not invoice_id:
        raise Exception("invoice_id is required in payload")
    
    cursor = db_conn.cursor(cursor_factory=RealDictCursor)
    
    # Lookup в order_ledger
    cursor.execute(
        """
        SELECT * FROM order_ledger
        WHERE tbank_invoice_id = %s
        LIMIT 1
        """,
        (invoice_id,)
    )
    
    record = cursor.fetchone()
    
    if not record:
        # Запись не найдена - логируем ошибку
        error_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "error_type": "ledger_lookup",
            "message": "Ledger record not found for invoice",
            "context": {
                "invoice_id": invoice_id,
                "invoice_number": invoice_number,
                "paid_at": paid_at
            }
        }
        
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": "tbank_invoice_paid_ledger_not_found",
            "invoice_id": invoice_id,
            "error": error_entry
        }
        print(json.dumps(log_entry))
        
        return {
            "job_type": "tbank_invoice_paid",
            "status": "completed",
            "message": "Invoice not found in ledger (logged)",
            "error": error_entry
        }
    
    order_id = record["order_id"]
    
    # Подготовка Event для FSM v2
    # event_id генерируем здесь (в реальности должен быть из job или внешнего источника)
    event_id = uuid4()
    
    event = Event(
        event_id=event_id,
        source="tbank",
        event_type="INVOICE_PAID",
        occurred_at=paid_at,
        payload={
            "invoice_id": invoice_id,
            "invoice_number": invoice_number,
            "paid_at": paid_at
        }
    )
    
    # Подготовка LedgerRecord для FSM v2
    state_history = record["state_history"]
    if isinstance(state_history, str):
        state_history = json.loads(state_history)
    
    metadata = record["metadata"]
    if isinstance(metadata, str):
        metadata = json.loads(metadata)
    
    ledger_record = LedgerRecord(
        order_id=UUID(str(order_id)),
        state=record["state"],
        state_history=state_history if state_history else [],
        metadata=metadata if metadata else {}
    )
    
    # Вызов FSM v2 (pure function)
    fsm_result = fsm_v2_process_event(event, ledger_record)
    
    # Применение результата FSM к Ledger
    if fsm_result.action == "skip":
        # Idempotent skip
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": "tbank_invoice_paid_idempotent",
            "order_id": str(order_id),
            "invoice_id": invoice_id,
            "current_state": fsm_result.from_state
        }
        print(json.dumps(log_entry))
        
        return {
            "job_type": "tbank_invoice_paid",
            "status": "completed",
            "message": "State already in target state (idempotent skip)",
            "order_id": str(order_id),
            "fsm_action": "skip"
        }
    
    elif fsm_result.action == "error":
        # FSM вернул ошибку - записываем в error_log
        error_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "error_type": fsm_result.error.get("error_type", "fsm_error"),
            "message": fsm_result.error.get("message", "FSM processing error"),
            "context": fsm_result.error.get("context", {}),
            "event_id": str(event_id)
        }
        
        cursor.execute(
            """
            UPDATE order_ledger
            SET error_log = error_log || %s::jsonb,
                updated_at = NOW()
            WHERE order_id = %s
            """,
            (json.dumps([error_entry]), order_id)
        )
        db_conn.commit()
        
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": "tbank_invoice_paid_fsm_error",
            "order_id": str(order_id),
            "invoice_id": invoice_id,
            "error": error_entry
        }
        print(json.dumps(log_entry))
        
        return {
            "job_type": "tbank_invoice_paid",
            "status": "completed",
            "message": "FSM error (logged)",
            "order_id": str(order_id),
            "error": error_entry,
            "fsm_action": "error"
        }
    
    elif fsm_result.action == "transition":
        # Выполняем transition
        cursor.execute(
            """
            UPDATE order_ledger
            SET state = %s,
                state_history = state_history || %s::jsonb,
                metadata = metadata || %s::jsonb,
                updated_at = NOW()
            WHERE order_id = %s
            RETURNING *
            """,
            (
                fsm_result.to_state,
                json.dumps([fsm_result.state_history_entry]),
                json.dumps(fsm_result.metadata_patch),
                order_id
            )
        )
        
        updated_record = cursor.fetchone()
        db_conn.commit()
        
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": "tbank_invoice_paid_transition_completed",
            "order_id": str(order_id),
            "invoice_id": invoice_id,
            "from_state": fsm_result.from_state,
            "to_state": fsm_result.to_state
        }
        print(json.dumps(log_entry))
        
        return {
            "job_type": "tbank_invoice_paid",
            "status": "completed",
            "message": "State transition completed",
            "order_id": str(order_id),
            "from_state": fsm_result.from_state,
            "to_state": fsm_result.to_state,
            "fsm_action": "transition"
        }
    
    else:
        # Неожиданный результат FSM
        raise Exception(f"Unexpected FSM action: {fsm_result.action}")


def execute_rfq_v1_from_ocr(payload: Dict[str, Any], db_conn) -> Dict[str, Any]:
    """
    Выполняет RFQ pipeline v1:
    1. Получить OCR результат (из job_queue или text напрямую)
    2. Deterministic parsing
    3. Опционально: LLM parsing
    4. Записать в rfq_requests и rfq_items
    """
    ocr_job_id = payload.get("ocr_job_id")
    text = payload.get("text")
    source = payload.get("source", "manual")
    llm_enabled = payload.get("llm_enabled", LLM_ENABLED_DEFAULT)
    
    # Получаем raw_text
    raw_text = text
    
    if ocr_job_id and not raw_text:
        # Читаем результат OCR из job_queue
        cursor = db_conn.cursor(cursor_factory=RealDictCursor)
        cursor.execute(
            """
            SELECT result, status 
            FROM job_queue 
            WHERE id = %s
            """,
            (ocr_job_id,)
        )
        ocr_job = cursor.fetchone()
        
        if not ocr_job:
            raise Exception(f"OCR job {ocr_job_id} not found")
        
        if ocr_job["status"] != "completed":
            raise Exception(f"OCR job {ocr_job_id} is not completed (status: {ocr_job['status']})")
        
        ocr_result = ocr_job["result"]
        if isinstance(ocr_result, str):
            ocr_result = json.loads(ocr_result)
        
        raw_text = ocr_result.get("sample_text", "") if ocr_result else ""
        
        if not raw_text:
            raise Exception(f"OCR job {ocr_job_id} has no text result")
    
    if not raw_text:
        raise Exception("No text provided (neither 'text' nor 'ocr_job_id' with result)")
    
    # Deterministic parsing
    parsed_result = parse_rfq_deterministic(raw_text)
    
    # Опционально: LLM parsing
    if llm_enabled:
        llm_result = parse_rfq_with_llm(raw_text)
        if llm_result:
            parsed_result = merge_llm_results(parsed_result, llm_result)
        else:
            parsed_result["llm_used"] = False
            parsed_result["llm_error"] = "LLM API unavailable, using deterministic parser only"
    else:
        parsed_result["llm_used"] = False
    
    # Записываем в rfq_requests
    cursor = db_conn.cursor()
    rfq_id = uuid4()
    
    cursor.execute(
        """
        INSERT INTO rfq_requests (id, source, raw_text, parsed_json, status)
        VALUES (%s, %s, %s, %s, 'processed')
        RETURNING id
        """,
        (rfq_id, source, raw_text, json.dumps(parsed_result))
    )
    rfq_id = cursor.fetchone()[0]
    
    # Записываем rfq_items
    part_numbers = parsed_result.get("candidate_part_numbers", [])
    items_count = 0
    
    for idx, part_num in enumerate(part_numbers[:100], start=1):  # Ограничиваем 100 элементами
        cursor.execute(
            """
            INSERT INTO rfq_items (rfq_id, line_no, part_number, qty, notes)
            VALUES (%s, %s, %s, NULL, NULL)
            """,
            (rfq_id, idx, part_num)
        )
        items_count += 1
    
    db_conn.commit()
    
    # Формируем summary
    return {
        "job_type": "rfq_v1_from_ocr",
        "rfq_id": str(rfq_id),
        "items_count": items_count,
        "sample_parts": part_numbers[:5] if part_numbers else [],
        "emails": parsed_result.get("emails", [])[:3],
        "phones": parsed_result.get("phones", [])[:3],
        "llm_used": parsed_result.get("llm_used", False)
    }


def execute_telegram_update(payload: Dict[str, Any], db_conn, job_id: UUID) -> Dict[str, Any]:
    """
    Новая обработка Telegram update через модульный router + dispatch_action.
    """
    telegram_payload = payload.get("payload")

    if not isinstance(telegram_payload, dict):
        log_event("telegram_update_invalid_payload", {
            "job_id": str(job_id),
            "payload_type": str(type(telegram_payload))
        })
        return {
            "job_type": "telegram_update",
            "status": "completed",
            "message": "Payload missing or invalid"
        }

    update_id = telegram_payload.get("update_id")
    log_event("telegram_update_router_start", {
        "job_id": str(job_id),
        "update_id": update_id
    })

    try:
        callback_query = telegram_payload.get("callback_query")
        if callback_query:
            callback_query_id = callback_query.get("id")
            if callback_query_id:
                answer_callback_query(callback_query_id)

        response_text, action = route_update(telegram_payload)
        chat_id = extract_chat_id_from_update(telegram_payload)

        if response_text and chat_id:
            send_telegram_message(chat_id, response_text)
        elif response_text:
            log_event("telegram_update_response_no_chat", {
                "update_id": update_id,
                "response_text": response_text
            })

        action_info = None
        if action:
            action_result = handle_router_action(action, db_conn)
            action_info = {
                "action_type": action.get("action_type"),
                "status": action_result.get("status")
            }

        log_event("telegram_update_router_completed", {
            "job_id": str(job_id),
            "update_id": update_id,
            "action_type": action.get("action_type") if action else None
        })

        return {
            "job_type": "telegram_update",
            "status": "completed",
            "message": "Telegram update processed via router",
            "update_id": update_id,
            "action": action_info
        }
    except Exception as e:
        db_conn.rollback()
        log_event("telegram_update_router_error", {
            "job_id": str(job_id),
            "update_id": update_id,
            "error": str(e)
        })
        raise


def execute_cdek_shipment_status(payload: Dict[str, Any], db_conn, job_id: UUID) -> Dict[str, Any]:
    """
    Обрабатывает CDEK shipment status update:
    1. Вызывает cdek_order_mapper
    2. Если OrderEvent → создает новый job (order_event)
    3. Если None → job completed
    """
    cursor = db_conn.cursor()
    
    try:
        # Вызываем mapper (нужен db_conn для lookup)
        order_event = map_cdek_to_order_event(payload, uuid4(), db_conn)
        
        if order_event is None:
            # Не найден заказ - завершаем job
            log_entry = {
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "event": "cdek_shipment_status_no_order",
                "job_id": str(job_id),
                "external_id": payload.get("external_id")
            }
            print(json.dumps(log_entry))
            
            return {
                "job_type": "cdek_shipment_status",
                "status": "completed",
                "message": "CDEK shipment status not mapped to order",
                "external_id": payload.get("external_id")
            }
        
        # Создаем новый job (order_event)
        order_event_payload = {
            "event_id": str(order_event.event_id),
            "source": order_event.source,
            "event_type": order_event.event_type,
            "external_id": order_event.external_id,
            "occurred_at": order_event.occurred_at,
            "payload": order_event.payload,
            "order_id": str(order_event.order_id)
        }
        
        order_event_idempotency_key = f"order_event:{order_event.source}:{order_event.external_id}"
        
        cursor.execute(
            """
            INSERT INTO job_queue (id, job_type, payload, status, idempotency_key)
            VALUES (gen_random_uuid(), %s, %s, 'pending', %s)
            RETURNING id
            """,
            ("order_event", json.dumps(order_event_payload), order_event_idempotency_key)
        )
        new_job_id = cursor.fetchone()[0]
        db_conn.commit()
        
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": "cdek_shipment_status_mapped_to_order_event",
            "job_id": str(job_id),
            "order_event_job_id": str(new_job_id),
            "order_id": str(order_event.order_id),
            "external_id": order_event.external_id
        }
        print(json.dumps(log_entry))
        
        return {
            "job_type": "cdek_shipment_status",
            "status": "completed",
            "message": "CDEK shipment status mapped to order event",
            "order_event_job_id": str(new_job_id),
            "order_id": str(order_event.order_id)
        }
        
    except Exception as e:
        db_conn.rollback()
        error_msg = str(e)
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": "cdek_shipment_status_error",
            "job_id": str(job_id),
            "error": error_msg
        }
        print(json.dumps(log_entry))
        raise


def execute_order_event(payload: Dict[str, Any], db_conn) -> Dict[str, Any]:
    """
    Обрабатывает order_event через FSM v2:
    1. Lookup order_ledger по order_id
    2. Если не найден - логируем ошибку, job completed
    3. Если найден - вызываем FSM v2
    4. Применяем изменения к Ledger
    """
    order_id_str = payload.get("order_id")
    if not order_id_str:
        raise Exception("order_id is required in order_event payload")
    
    try:
        order_id = UUID(order_id_str)
    except (ValueError, TypeError):
        raise Exception(f"Invalid order_id format: {order_id_str}")
    
    cursor = db_conn.cursor(cursor_factory=RealDictCursor)
    
    # Lookup в order_ledger
    cursor.execute(
        """
        SELECT * FROM order_ledger
        WHERE order_id = %s
        LIMIT 1
        """,
        (order_id,)
    )
    
    record = cursor.fetchone()
    
    if not record:
        error_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "error_type": "ledger_lookup",
            "message": "Ledger record not found for order_id",
            "context": {
                "order_id": order_id_str,
                "source": payload.get("source"),
                "event_type": payload.get("event_type")
            }
        }
        
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": "order_event_ledger_not_found",
            "order_id": order_id_str,
            "error": error_entry
        }
        print(json.dumps(log_entry))
        
        return {
            "job_type": "order_event",
            "status": "completed",
            "message": "Order not found in ledger (logged)",
            "error": error_entry
        }
    
    # Подготовка Event для FSM v2
    event_id = UUID(payload.get("event_id", str(uuid4())))
    
    event = Event(
        event_id=event_id,
        source=payload.get("source", "unknown"),
        event_type=payload.get("event_type", "unknown"),
        occurred_at=payload.get("occurred_at", datetime.utcnow().isoformat() + "Z"),
        payload=payload.get("payload", {})
    )
    
    # Подготовка LedgerRecord для FSM v2
    state_history = record["state_history"]
    if isinstance(state_history, str):
        state_history = json.loads(state_history)
    
    metadata = record["metadata"]
    if isinstance(metadata, str):
        metadata = json.loads(metadata)
    
    ledger_record = LedgerRecord(
        order_id=UUID(str(record["order_id"])),
        state=record["state"],
        state_history=state_history if state_history else [],
        metadata=metadata if metadata else {}
    )
    
    # Вызов FSM v2 (pure function)
    fsm_result = fsm_v2_process_event(event, ledger_record)
    
    # Применение результата FSM к Ledger
    if fsm_result.action == "skip":
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": "order_event_idempotent",
            "order_id": order_id_str,
            "current_state": fsm_result.from_state
        }
        print(json.dumps(log_entry))
        
        return {
            "job_type": "order_event",
            "status": "completed",
            "message": "State already in target state (idempotent skip)",
            "order_id": order_id_str,
            "fsm_action": "skip"
        }
    
    elif fsm_result.action == "error":
        error_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "error_type": fsm_result.error.get("error_type", "fsm_error"),
            "message": fsm_result.error.get("message", "FSM processing error"),
            "context": fsm_result.error.get("context", {}),
            "event_id": str(event_id)
        }
        
        cursor.execute(
            """
            UPDATE order_ledger
            SET error_log = error_log || %s::jsonb,
                updated_at = NOW()
            WHERE order_id = %s
            """,
            (json.dumps([error_entry]), order_id)
        )
        db_conn.commit()
        
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": "order_event_fsm_error",
            "order_id": order_id_str,
            "error": error_entry
        }
        print(json.dumps(log_entry))
        
        return {
            "job_type": "order_event",
            "status": "completed",
            "message": "FSM error (logged)",
            "order_id": order_id_str,
            "error": error_entry,
            "fsm_action": "error"
        }
    
    elif fsm_result.action == "transition":
        cursor.execute(
            """
            UPDATE order_ledger
            SET state = %s,
                state_history = state_history || %s::jsonb,
                metadata = metadata || %s::jsonb,
                updated_at = NOW()
            WHERE order_id = %s
            RETURNING *
            """,
            (
                fsm_result.to_state,
                json.dumps([fsm_result.state_history_entry]),
                json.dumps(fsm_result.metadata_patch),
                order_id
            )
        )
        
        updated_record = cursor.fetchone()
        db_conn.commit()
        
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": "order_event_transition_completed",
            "order_id": order_id_str,
            "from_state": fsm_result.from_state,
            "to_state": fsm_result.to_state
        }
        print(json.dumps(log_entry))
        
        return {
            "job_type": "order_event",
            "status": "completed",
            "message": "State transition completed",
            "order_id": order_id_str,
            "from_state": fsm_result.from_state,
            "to_state": fsm_result.to_state,
            "fsm_action": "transition"
        }
    
    else:
        raise Exception(f"Unexpected FSM action: {fsm_result.action}")


def process_job(job: Dict[str, Any], db_conn) -> Dict[str, Any]:
    """Обрабатывает задачу в зависимости от job_type"""
    job_type = job.get("job_type", "")
    payload = job.get("payload", {})
    job_id = job.get("id")
    
    if isinstance(payload, str):
        payload = json.loads(payload)
    
    if job_type == "test_job":
        return execute_test_job(payload)
    elif job_type == "rfq_v1_from_ocr":
        return execute_rfq_v1_from_ocr(payload, db_conn)
    elif job_type == "tbank_invoice_paid":
        return execute_tbank_invoice_paid(payload, db_conn)
    elif job_type == "telegram_update":
        if not job_id:
            raise Exception("job_id is required for telegram_update")
        return execute_telegram_update(payload, db_conn, UUID(str(job_id)))
    elif job_type == "telegram_command":
        return execute_telegram_command(payload, db_conn)
    elif job_type == "cdek_shipment":
        return execute_cdek_shipment(payload, db_conn)
    elif job_type == "cdek_shipment_status":
        if not job_id:
            raise Exception("job_id is required for cdek_shipment_status")
        return execute_cdek_shipment_status(payload, db_conn, UUID(str(job_id)))
    elif job_type == "insales_paid_sync":
        return execute_insales_paid_sync(payload, db_conn)
    elif job_type == "invoice_create":
        return execute_invoice_create(payload, db_conn)
    elif job_type == "order_event":
        return execute_order_event(payload, db_conn)
    else:
        raise Exception(f"Unknown job_type for RU worker: {job_type}")


def main():
    """Главный цикл RU worker"""
    print("RU Worker started")
    print(f"POSTGRES: {POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}")
    print(f"POLL_INTERVAL: {POLL_INTERVAL}s")
    print(f"LLM_ENABLED_DEFAULT: {LLM_ENABLED_DEFAULT}")
    print("Press Ctrl+C to stop\n")
    
    while True:
        conn = None
        try:
            conn = get_db_connection()
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            
            # SELECT RU-side jobs (включая новые side-effect workers)
            cursor.execute(
                """
                SELECT * FROM job_queue 
                WHERE status = 'pending' 
                  AND job_type IN ('test_job', 'rfq_v1_from_ocr', 'tbank_invoice_paid', 'telegram_update', 'telegram_command', 'cdek_shipment', 'cdek_shipment_status', 'insales_paid_sync', 'invoice_create', 'order_event')
                ORDER BY created_at ASC 
                LIMIT 1 
                FOR UPDATE SKIP LOCKED
                """
            )
            
            job = cursor.fetchone()
            
            if not job:
                # Нет задач, ждем
                time.sleep(POLL_INTERVAL)
                continue
            
            job_id = job["id"]
            job_type = job["job_type"]
            payload = job["payload"]
            
            if isinstance(payload, str):
                payload = json.loads(payload)
            
            print(f"Processing job: {job_id} ({job_type})")
            
            # UPDATE на processing
            cursor.execute(
                """
                UPDATE job_queue 
                SET status = 'processing', updated_at = NOW() 
                WHERE id = %s
                """,
                (job_id,)
            )
            conn.commit()
            
            # Выполняем задачу
            try:
                result = process_job(dict(job), conn)
                
                # UPDATE на completed с result
                cursor.execute(
                    """
                    UPDATE job_queue 
                    SET status = 'completed', 
                        result = %s,
                        updated_at = NOW() 
                    WHERE id = %s
                    """,
                    (json.dumps(result), job_id)
                )
                conn.commit()
                
                print(f"Job {job_id} completed successfully\n")
                
            except Exception as e:
                error_msg = str(e)
                print(f"Job {job_id} failed: {error_msg}")
                
                # UPDATE на failed
                cursor.execute(
                    """
                    UPDATE job_queue 
                    SET status = 'failed', 
                        error = %s,
                        updated_at = NOW() 
                    WHERE id = %s
                    """,
                    (error_msg, job_id)
                )
                conn.commit()
            
        except KeyboardInterrupt:
            print("\nStopping RU worker...")
            break
        except Exception as e:
            print(f"Unexpected error in main loop: {e}")
            time.sleep(POLL_INTERVAL)
        finally:
            if conn:
                cursor.close()
                conn.close()


if __name__ == "__main__":
    main()

